/*
  Живой чат Azure Shadows: локальный сервер, который отдаёт сайт
  и последние сообщения группы через MTProto (библиотека telegram).

  Запуск из папки server:  node server.mjs
  Сайт открывается на http://localhost:8787
*/
import { readFile, stat } from "node:fs/promises";
import { createServer } from "node:http";
import { join, resolve, extname } from "node:path";
import { homedir } from "node:os";
import { TelegramClient } from "telegram";
import { StringSession } from "telegram/sessions/index.js";

const ROOT = resolve(import.meta.dirname, "..");
const CHAT = -1004310385149; // группа Azure Shadows
const LIMIT = 25;
const PORT = 8787;

const apiId = Number(process.env.TELEGRAM_API_ID);
const apiHash = process.env.TELEGRAM_API_HASH;
if (!apiId || !apiHash) {
  console.error("Нет TELEGRAM_API_ID или TELEGRAM_API_HASH в переменных окружения.");
  process.exit(1);
}

let sessionString = "";
try {
  const p = join(homedir(), ".mcp-telegram", "session");
  sessionString = (await readFile(p, "utf8")).trim();
} catch {
  console.error("Сессия Telegram не найдена в %HOMEPATH%\\.mcp-telegram\\session.");
  process.exit(1);
}

const client = new TelegramClient(new StringSession(sessionString), apiId, apiHash, {
  connectionRetries: 5,
  useWSS: true,
});
await client.connect();

const entity = await client.getEntity(CHAT);
console.log("Telegram: подключено,", entity.title ?? "");

const ago = Date.now();
const moscow = (d, opts) => new Intl.DateTimeFormat("ru-RU", { timeZone: "Europe/Moscow", ...opts }).format(d);

async function readMessages() {
  const rows = await client.getMessages(entity, { limit: LIMIT });
  const now = new Date();
  return {
    live: true,
    takenAtLabel: "сейчас, " + moscow(now, { hour: "2-digit", minute: "2-digit" }) + " по мск",
    chatName: entity.title ?? "Azure Shadows",
    members: typeof entity.participantsCount === "number" ? entity.participantsCount : undefined,
    messages: rows.map((m) => {
      let author = "";
      const s = m.sender;
      if (s) {
        author = s.firstName || s.title || "";
        if (s.lastName) author += " " + s.lastName;
        if (!author && s.username) author = "@" + s.username;
      }
      if (!author) author = "участник";

      let text = (m.message || "").trim();
      if (!text) {
        const med = String(m.className || "");
        const map = {
          MessageService: "",
          MessageMediaDocument: "[файл]",
        };
        text = map[med] || "[медиа]";
        if (m.media?.className === "MessageMediaDocument" && m.media.stickerSet) text = "[стикер]";
        else if (m.media?.className === "MessageMediaPhoto") text = "[фото]";
        else if (m.media?.className === "MessageMediaGeo") text = "[геометка]";
        else if (m.media?.className === "MessageMediaDice") text = "[кубик]";
      }

      return {
        id: m.id,
        time: moscow(new Date((m.date || 0) * 1000), { hour: "2-digit", minute: "2-digit" }),
        author: author.trim(),
        bot: !!s?.bot,
        text,
      };
    }),
  };
}

let cache = null;
let cacheAt = 0;
async function messagesCached() {
  if (cache && Date.now() - cacheAt < 4000) return cache; // не дёргать Telegram чаще раза в 4 секунды
  cache = await readMessages();
  cacheAt = Date.now();
  return cache;
}

const TYPES = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
};

const server = createServer(async (req, res) => {
  const url = new URL(req.url, "http://localhost");
  try {
    if (url.pathname === "/api/messages") {
      const data = await messagesCached();
      res.writeHead(200, { "content-type": TYPES[".json"] });
      res.end(JSON.stringify(data));
      return;
    }

    let path = decodeURIComponent(url.pathname).replace(/^\/+/, "").replace(/\/+$/, "");
    if (path === "") path = "index.html";
    const file = resolve(ROOT, path);
    if (!file.startsWith(ROOT) || path === "server.mjs" || path.startsWith("server" + "/")) {
      res.writeHead(403);
      res.end("Запрещено");
      return;
    }
    const info = await stat(file);
    if (!info.isFile()) throw new Error("dir");
    res.writeHead(200, { "content-type": TYPES[extname(file)] || "application/octet-stream" });
    res.end(await readFile(file));
  } catch (err) {
    // Ошибки Telegram отдаём JSON — страница покажет сообщение и уйдёт в срез
    if (url.pathname === "/api/messages") {
      res.writeHead(503, { "content-type": TYPES[".json"] });
      res.end(JSON.stringify({ live: false, error: String(err.message || err) }));
      return;
    }
    res.writeHead(404);
    res.end("Страницы нет");
  }
});

server.listen(PORT, () => {
  console.log(`Сайт: http://localhost:${PORT}  (Ctrl+C — остановить)`);
});
